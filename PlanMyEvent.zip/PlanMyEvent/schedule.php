<HTML>
<HEAD>
<TITLE>PlanMyEvent</TITLE>
<style type="text/css">
@import url(style.css);
#logo { 
  border-radius: 25px;
    border: 1px solid blue; 
    width: 100px;
    height: 100px; 
}
* {
  color: black;
}
html { 
  background: url(img/bg7.jpg) no-repeat center center fixed; 
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;
}
#main {
    width:700px;
    height: 400px;
    margin: 0 auto;
    margin-top: 30px;
    color:black;
    border-radius: 25px;
      padding-top: 10px;
      padding-right: 10px;
      padding-bottom: 10px;
      padding-left: 10px;
      background-color: rgba(0,0,0,0.3);
  }
  .card{
    background-color:lightblue;
    width:40%;
    border:solid black;
  }
  table, td, th {
  border: 1px solid black;
}

table {
  border-collapse: collapse;
  width: 97%;
}

th,td {
  text-align: center;
}
</style>
</HEAD>
    
<img src="img/home.jpg" alt="home" width="100%" height="300">

<?php
 include("header.php");
session_start();

if(isset($_SESSION['user']))
  echo '<h3 align="center"><a href="ticket.php"></a></h3>';
else
  echo '<h3 align="center"><a href="login.php">Please register/login before booking</a></h3>';


$con=mysqli_connect("localhost","project","project","dbms1");
// Check connection
if (mysqli_connect_errno())
{
echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
$email=$_SESSION['user'];
//echo $email;
$sql2="select Uid from users where email='$email'";
$id=mysqli_query($con,$sql2);
$row=mysqli_fetch_assoc($id);
$u_id=$row['Uid'];


$result = mysqli_query($con,"select * from addevent where sid='$u_id'");
echo "<table border='1'>
<tr>
<th>ID</th>
<th>Event Name</th>
<th>Contact</th>
<th>Comapany</th>
<th>Event Type</th>
<th>Date</th>

</tr>";

while($row = mysqli_fetch_array($result))
{
echo "<tr>";
echo "<td>" . $row['eid']. "</td>";
echo "<td>" . $row['ename'] . "</td>";
echo "<td>" . $row['contact'] . "</td>";
echo "<td>" . $row['company'] . "</td>";
echo "<td>" . $row['etype'] . "</td>";
echo "<td>" . $row['date'] . "</td>";


echo "</tr>";
}
echo "</table>";

mysqli_close($con);
?>