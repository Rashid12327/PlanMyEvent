
    <?php
    session_start();
    ?>
    <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Shaikh Rashid</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
</head>
<body>
    <header>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="event.php">Event</a></li>
                <li><a href="contactus.php">Contact us</a></li>
                <li style="padding-left:40%"><a href="schedule.php">My Activity</a></li>
                <?php
                if (isset($_SESSION['user'])) {
                ?>
                <li ><a href="logout.php">Logout</a></li>
                <?php

                } else {
                ?>
                <li><a href="login.php">Login</a></li>
                <?php
                } echo $_SESSION['user'];?>
            </ul>
        </nav>
    </header>
    <h1>PlanMyEvent</h1>