<?php
include("checkdb.php");
session_start();
if(isset($_SESSION['user']))
  echo '<h3 align="center"><a href="ticket.php"></a></h3>';
else
  echo '<h3 align="center"><a href="register.php">Please register/login before booking</a></h3>';
  $con=mysqli_connect("localhost","project","project","dbms1");

$email=$_SESSION['user'];
//echo $email;
$sql2="select Uid from users where email='$email'";
$id=mysqli_query($con,$sql2);
$row=mysqli_fetch_assoc($id);
$u_id=$row['Uid'];

if($_POST['submit'])
{
	$ename=$_POST['ename'];
	$contact=$_POST['contact'];
	

	$company=$_POST['company'];
	$type=$_POST['etype'];
	$message=$_POST['message'];
	$date=$_POST['date'];



	$sql="INSERT INTO addevent(ename,contact,company,etype,message,date,sid) values ('$ename','$contact','$company','$type','$message','$date','$u_id')";
	if($conn->query($sql)===TRUE)
	{
		echo "Record Inserted";
		header("Refresh:2,url=event.php"); 
	}
	else
	{
		echo $conn->error;
	}

}

?>