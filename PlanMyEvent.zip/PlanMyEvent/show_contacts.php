<HTML>
<HEAD>
<TITLE>PlanMyEvent</TITLE>
<link rel="stylesheet" href="css/admin.css">

</style>
</HEAD>
<body>
        <center>
    
        <h1>Admin Panel</h1>
       
        </center>
        
        <header>
        <div class="nav">
        <nav>
        <ul>
                
               
				<li><a class="active" href="adminbooking.php"><i class="fa fa-fw fa-user"></i>Events</a></li>
                <li><a class="active" href="totalusers.php"><i class="fa fa-fw fa-user"></i>Users</a></li>
                
        
        <li><a class="active" href="show_contacts.php"><i class="fa fa-fw fa-user"></i>User Contacts</a></li>
        <?php session_start();
                if (isset($_SESSION['username'])) {
                ?>
                
        <li style="padding-left:60%"><a class="active" href="adminlogout.php"><i class="fa fa-fw fa-user"></i>Logout</a></li>
				
                <?php

                } else {
                ?>
               <li style="float:right"><a class="active" href="adminlogin.php"><i class="fa fa-fw fa-user"></i>Login</a></li>
                <?php
                }echo $_SESSION['username']; ?>

                
        </ul> 
        </nav>
        </div>
            </Header> 
            <style>
 table, td, th {
  border: 1px solid black;
  
}

table {
  border-collapse: collapse;
  width: 97%;
  padding:15px;
}

th,td {
  text-align: center;
}
</style>


<?php
 


if(isset($_SESSION['user']))
  echo '<h3 align="center"></h3>';
else
  echo '<h3 align="center"><Please register/login before booking</h3>';


$con=mysqli_connect("localhost","project","project","dbms1");
// Check connection
if (mysqli_connect_errno())
{
echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
$email=$_SESSION['user'];
//echo $email;
$sql2="select Uid from users where email='$email'";
$id=mysqli_query($con,$sql2);
$row=mysqli_fetch_assoc($id);
$u_id=$row['Uid'];


$result = mysqli_query($con,"select * from user");

echo "<table border='1'>
<tr>
<th>ID</th>
<th> Name</th>

<th>Issue</th>
<th>Feedback</th>

</tr>";

while($row = mysqli_fetch_assoc($result))
{
echo "<tr>";
echo "<td>" . $row['id']. "</td>";
echo "<td>" . $row['sname'] . "</td>";

echo "<td>" . $row['subject'] . "</td>";
echo "<td>" . $row['message'] . "</td>";


echo "</tr>";
}
echo "</table><br><br>";

mysqli_close($con);
?>
  <footer>
      &copy; 2019  PlanMyEvent ,All Right Reserved .
</footer>