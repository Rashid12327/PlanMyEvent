<!DOCTYPE HTML>
<html>
    <head>
            <title>MyProject</title>
            <meta charset="UTF-8">
            
            <link rel="stylesheet" type="text/css" href="css/admin.css"/>

            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <script src="js/main.js"></script>
            
    </head>
    <body>
    <center>
    
    <h1>Admin Panel</h1>
   
    </center>
        <header>
        <div class="nav">
        <nav>
        <ul>
                
                <?php session_start();
                if (isset($_SESSION['username'])) {
                ?>
                
				<li><a class="active" href="adminbooking.php">Events</a></li>
                <li><a class="active" href="totalusers.php">Users</a></li>
                
        
        <li><a class="active" href="show_contacts.php">User Contacts</a></li>
                <li style="padding-left:60%"><a class="active" href="adminlogout.php"><i class="fa fa-fw fa-user"></i>Logout</a></li>
				
                <?php

                } else {
                ?>
               <li style="float:right"><a class="active" href="adminlogin.php"><i class="fa fa-fw fa-user"></i>Login</a></li>
                <?php
                } ?>
                
        </ul> 
        </nav>
        </div>
            </Header>
		
		<?php 
			include("checkdb.php");
			$sql1="select * from addevent";
			$val=mysqli_query($conn,$sql1);
			
			?>
			<style>
 table, td, th {
  border: 1px solid black;
  
}

table {
  border-collapse: collapse;
  width: 97%;
  padding:15px;
}

th,td {
  text-align: center;
}
</style>
<p>________________________________________________________________________________________________________________________________________________________________________</p>
				<table >
				 <tr>
	  <th>ID</th>
<th>Event Name</th>
<th>Contact</th>
<th>Comapany</th>
<th>Event Type</th>
<th>Date</th>
    </tr><?php
			while($row=mysqli_fetch_assoc($val)){
			
				
        echo "<tr>";
        echo "<td>" . $row['eid']. "</td>";
        echo "<td>" . $row['ename'] . "</td>";
        echo "<td>" . $row['contact'] . "</td>";
        echo "<td>" . $row['company'] . "</td>";
        echo "<td>" . $row['etype'] . "</td>";
        echo "<td>" . $row['date'] . "</td>";
		?>
			<?php
			}
		?>
	</table>
	<table>
	<tr>
		
	
		</tr>
	</table>			
		<hr>
      
     
       
  <footer>
      &copy; 2019  PlanMyEvent ,All Right Reserved .
</footer>
    </body>
</html>
