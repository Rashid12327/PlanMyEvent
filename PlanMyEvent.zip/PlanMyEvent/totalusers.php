<!DOCTYPE HTML>
<html>
    <head>
            <title>MyProject</title>
            <meta charset="UTF-8">
            
            <link rel="stylesheet" type="text/css" href="css/admin.css"/>
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <script src="js/main.js"></script>
            
    </head>
    <body>
   <center>
    
        <h1>Admin Panel</h1>
       
        </center>
        <header>
        <div class="nav">
        <nav>
        <ul>
                
                <?php session_start();
                if (isset($_SESSION['username'])) {
                ?>
                
				<li><a class="active" href="adminbooking.php"><i class="fa fa-fw fa-user"></i>Events</a></li>
                <li><a class="active" href="totalusers.php"><i class="fa fa-fw fa-user"></i>Users</a></li>
                
        
        <li><a class="active" href="show_contacts.php"><i class="fa fa-fw fa-user"></i>User Contacts</a></li>
                <li style="padding-left:60%"><a class="active" href="adminlogout.php"><i class="fa fa-fw fa-user"></i>Logout</a></li>
				
                <?php

                } else {
                ?>
               <li style="float:right"><a class="active" href="adminlogin.php"><i class="fa fa-fw fa-user"></i>Login</a></li>
                <?php
                } ?>
                
        </ul> 
        </nav>
        </div>
            </Header>
            <style>
 table, td, th {
  border: 1px solid black;
  
}

table {
  border-collapse: collapse;
  width: 97%;
  padding:15px;
}

th,td {
  text-align: center;
}
</style>
		
		<?php 
			include("checkdb.php");
			$sql1="select * from users";
			$val=mysqli_query($conn,$sql1);
			
			?>
			<style>
 table, td, th {
  border: 1px solid black;
}

table {
  border-collapse: collapse;
  width: 97%;
}

th,td {
  text-align: center;
}
}
</style>
<p>________________________________________________________________________________________________________________________________________________________________________</p>
				<table >
				 <tr>
	  <th>ID</th>
<th>Name</th>

<th>Address</th>
<th>EPassword</th>
<th>Email</th>
    </tr><?php
			while($row=mysqli_fetch_assoc($val)){
			
				
        echo "<tr>";
        echo "<td>" . $row['Uid']. "</td>";
        echo "<td>" . $row['name'] . "</td>";
        echo "<td>" . $row['address'] . "</td>";
       
        echo "<td>" . $row['pass'] . "</td>";
        echo "<td>" . $row['email'] . "</td>";
		?>
			<?php
			}
		?>
	</table>
	<table>
	<tr>
		
	
		</tr>
	</table>			
		<hr>
      
      
  </center>
  <footer>
      &copy; 2019  PlanMyEvent ,All Right Reserved .
</footer>
    </body>
</html>
