<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>PlanMyEvent</title>
    <link rel="stylesheet" href="css/registration.css">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <script type="text/javascript" src="js/validate.js"></script>
    

    
</head>
<body>
<img src="img/home.jpg" alt="home" width="100%" height="300">
   <header>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="event.php">Event</a></li>
                <li><a href="contactus.php">Contact us</a></li>
                <?php
                if (isset($_SESSION['user'])) {
                ?>
                <li style="padding-left:59%"><a href="logout.php">Logout</a></li>
                <?php

                } else {
                ?>
                <li style="padding-left:59%"><a href="login.php">Login</a></li>
                <?php
                } ?>
                <?php 
                echo $_SESSION['user'];?>
            </ul>
        </nav>
    </header>
    <h1>PlanMyEvent</h1>
<form method="POST" action="eventaction.php">
        <div class="container">
          <h2>Add Event</h2>
          <p>Please fill the Details.</p>
          <hr>
          
          <label for="name"><b>Event Name</b></label>
          <input type="text" placeholder="Enter name" name="ename" id="ename" required><br>

          <label for="contact"><b>Contact No:</b></label>
          <input type="contact" placeholder="Enter number" name="contact" id="contact" required><br><br>
          

         

          <label for="company"><b>Company Name</b></label>
          <input type="text" placeholder="Enter company" name="company" id="company" required><br>
          
          <label for="type"><b>Event Type</b></label>
           
          <select name="etype" required><br>
            <option value="Music">Music</option>
            <option value="Wedding">Wedding</option>
            <option value="Conference">Conference</option>
            <option value="Birthday">Birthday</option>
            </select><br><br>



          <label for="date"><b>Date</b></label>
          <input type="date"  name="date" id="date" required><br><br>

          

      
          <label for="message"><b>Description</b></label>
          <textarea type="message" id="message" name="message" rows="3" cols="40" required></textarea><br>
                <div class="clearfix">
                        <input type="button" class="cancelbtn" value="Cancel">
                        <input type="submit" name="submit" id="submit" class="signupbtn" value="Submit">            </div>
            
        
          

        </div>
        <footer>
                <center>
                &copy; 2019 Shaikh Rashid,All Right Reserved .</center>
                        
        </footer>
      </form> 
      </body>
      
      
      </html>

      