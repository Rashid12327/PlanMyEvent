<?php session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <style>
    #status{

    }
    </style>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>PlanMyEvent</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <script type="text/javascript" src="js/jquery-3.4.1.min.js"> </script>
</head>
<body>
<img src="img/home.jpg" alt="home" width="100%" height="300">
    <header>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="event.php">Event</a></li>
                <li><a href="contactus.php">Contact us</a></li>
                <?php session_start();

                if (isset($_SESSION['user'])) {
                ?>
                <li style="padding-left:59%"><a href="logout.php">Logout</a></li>
                <?php

                } else {
                ?>
                <li style="padding-left:59%"><a href="login.php">Login</a></li>
                <?php
                } ?>
                <?php 
                echo $_SESSION['user'];?>
                <li><a class="active" href="adminlogin.php">Admin Login</a></li>
                
            </ul>
        </nav>
    </header>
    <h1>PlanMyEvent</h1>
    <section>
        <article class="login">
            <div class="card">
                <h2>Login</h2>
                
                <?php
                if($_POST)
                {
                    $email=$_POST['email'];
                    $password=$_POST['password'];
                    include("checkdb.php");
                    $sql="select * from users where email='$email' and pass='$password'";
                    $result=$conn->query($sql);
                    if($result->num_rows == 1)
                {
                ?>
                    <script>
                    $(function() {
                        $('#status').html('<center> Login Successful ! <br/> Redirecting to home page</center>').fadeIn().delay(2000).fadeOut();
                    });
                    </script>
                <?php
                    $_SESSION['user']=$email;
                    
                    header("Refresh:3,url=index.php");
                }
                else
                {
                    ?>
                    <script>
                        $(function(){
                            $('#status').html('<center>Incorrect email or Password !</center>').fadeIn().delay(2000).fadeOut();

                        });
                    </script>
                    <?php
                }
                }
                ?>

               
    <main>
        
                    
                    
            <h1><b>Please Signin Your Account !</b></h1>
        
            <form method="post" action="login.php">
                    email:
                    <input type="email" name="email" id="email" placeholder="email" required /><br>
                    password:
                    <input type="password" name="password" id="password" placeholder="password" required /><br>
                    <input type="submit" id="submit" value="login"><br>
                    <a href="registration.php">New Registration..</a>
                    <div id='status'>
                 
            </form>
            </div>
         </main>
            </article>
         </section>
        <footer>
            &copy; 2019 Shaikh Rashid,All Right Reserved .
    
        </footer>
    </body>
    </html>