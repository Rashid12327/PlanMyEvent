<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <style type="text/css">
    #more {display: none;}
    #status{

    }
    </style>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>PlanMyEvent</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <script type="text/javascript" src="js/app.js"></script>
</head>
<body>
<img src="img/home.jpg" alt="home" width="100%" height="300">
    <header>
        
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="event.php">Event</a></li>
                <li><a href="contactus.php">Contact us</a></li>
                <?php
                if (isset($_SESSION['user'])) {
                ?>
                <li style="padding-left:59%"><a href="logout.php">Logout</a></li>
                <?php

                } else {
                ?>
                <li style="padding-left:59%"><a href="login.php">Login</a></li>
                <?php
                } ?>
                <?php 
                echo $_SESSION['user'];?>
                
            
              
                
            </ul>
        </nav>
    </header>
    <h1>PlanMyEvent</h1>
    <?php
    include("header2.php"); 
    ?>
   

   <h2>Career</h2>

<p>Perceptites receive an unparalleled exposure to a multitude of options spanning the advertising
    , public relations, media, digital, entertainment, sports, fashion, music and content domain.<span id="dots">...</span>
    <span id="more">
Extensive corporate training and induction is provided, which includes introduction to the various 
spectrum of activities handled by Percept along with opportunities for lateral movement across the Percept Group of Companies as per the individual stream preferences.
The training, learning, exposure, opportunity and experience attained at Percept has created and launched many a spectacular career.</span></p> 
    
<button onclick="myFunction()" id="myBtn">Read more</button>
            </div>
            
 
</div><section>
        
            </section>
            <footer>
            &copy; 2019 PlanMyEvent,All Right Reserved .
    
            </footer>
            </body>
            </html>
