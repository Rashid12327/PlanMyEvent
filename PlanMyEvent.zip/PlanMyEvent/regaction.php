<?php
    include("checkdb.php");
    //include("header.php");
    if($_POST['signup_btn'])
        {
            $name=$_POST['name'];
            $address=$_POST['address'];
            
            $pass=$_POST['pass'];
            $email=$_POST['email'];


            $sql= "INSERT INTO users (name,address,pass,email) values ('$name','$address','$pass','$email')";
            
            //echo $sql; // for testing purpose

            if($conn->query($sql)===TRUE)
            {
                echo"<h2> New Records are inserted successfully</h2>";
                header("Refresh:2,url=login.php");
            }
            else
            {
                echo $conn->error;
            }
        }
       ?>
