<?php 
include("checkdb.php");
session_start();
?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
  nav a{
    color :whitesmoke;
    text-decoration: none;
    
}
header{
    top: 0%;
}
footer{
    bottom: 0%;
    color :whitesmoke;
}
nav ul>li{
    list-style: none;
    display: inline-block;
    margin-left: 10px;
}
header,footer{
    background-color:rgb(33, 95, 177);
    padding: 20px;
    position: static;
    width: 100%; 

}
footer{
    bottom: 0;
    text-align: center;

}
nav ul{
    margin: 0;
    padding: 0;
}
* {box-sizing: border-box;}
body {font-family: Verdana, sans-serif;}
.mySlides {display: none;}
img {vertical-align: middle;}

/* Slideshow container */
.slideshow-container {
  max-width: 1000px;
  position: relative;
  margin: auto;
}

/* Caption text */
.text {
  color: #f2f2f2;
  font-size: 15px;
  padding: 8px 12px;
  position: absolute;
  bottom: 8px;
  width: 100%;
  text-align: center;
}

/* Number text (1/3 etc) */
.numbertext {
  color: #f2f2f2;
  font-size: 12px;
  padding: 8px 12px;
  position: absolute;
  top: 0;
}

/* The dots/bullets/indicators */
.dot {
  height: 15px;
  width: 15px;
  margin: 0 2px;
  background-color: #bbb;
  border-radius: 50%;
  display: inline-block;
  transition: background-color 0.6s ease;
}

.active {
  background-color: #717171;
}

/* Fading animation */
.fade {
  -webkit-animation-name: fade;
  -webkit-animation-duration: 1.5s;
  animation-name: fade;
  animation-duration: 1.5s;
}

@-webkit-keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

@keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

/* On smaller screens, decrease text size */
@media only screen and (max-width: 300px) {
  .text {font-size: 11px}
}
p{
  text-align:center;
}
</style>
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
</head>
<body>
<img src="img/home.jpg" alt="home" width="100%" height="300">
<header>

        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="event.php">Event</a></li>
                <li><a href="contactus.php">Contact us</a></li>
                <li style="padding-left:50%"><a href="schedule.php">My Activity</a></li>
                <?php
                if (isset($_SESSION['user'])) {
                ?>
                <li ><a href="logout.php">Logout</a></li>
                <?php

                } else {
                ?>
                <li><a href="login.php">Login</a></li>
                <?php
                } //echo $_SESSION['user'];?>
                
               
            </ul>
        </nav>
    </header>
    <h1>PlanMyEvent</h1>

<h2>Venue</h2>
<p>All Venues</p>

<div class="slideshow-container">

<div class="mySlides fade">
  <div class="numbertext">1 / 7</div>
  <img src="img/venue1.jpg" width="100%" height="300">
  <div class="text">Mumbai</div>
</div>

<div class="mySlides fade">
  <div class="numbertext">2 / 7</div>
  <img src="img/venue2.jpg" width="100%" height="300">
  <div class="text">Delhi</div>
</div>

<div class="mySlides fade">
  <div class="numbertext">3 / 7</div>
  <img src="img/venue3.jpg" width="100%" height="300">
  <div class="text">Newyork</div>
</div>
<div class="mySlides fade">
  <div class="numbertext">4 / 7</div>
  <img src="img/venue4.jpg" width="100%" height="300">
  <div class="text">Navi Mumbai</div>
</div>

<div class="mySlides fade">
  <div class="numbertext">5 / 7</div>
  <img src="img/venue5.jpg" width="100%" height="300">
  <div class="text">Lucknow</div>
</div>

<div class="mySlides fade">
  <div class="numbertext">6 / 7</div>
  <img src="img/venue6.jpg" width="100%" height="300">
  <div class="text">Chandigarh</div>
</div>
<div class="mySlides fade">
  <div class="numbertext">7 / 7</div>
  <img src="img/venue7.jpg" width="100%" height="300">
  <div class="text">Goa</div>
</div>

</div>
<br>

<div style="text-align:center">
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span> 
  
</div>
<br><br>
<script>
var slideIndex = 0;
showSlides();

function showSlides() {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("dot");
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";  
  }
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1}    
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
  setTimeout(showSlides, 6000); // Change image every 2 seconds
}
</script>

</body>
</html> 
