function myMarks(){
    var  name, lname, iname,batch;
    var tcs, cn, wdl, dloc, bce, dbms;
    var total, percent, grade;

    name = document.getElementById("name").value;
    lname = document.getElementById("lname").value;
    iname = document.getElementById("iname").value;
    batch = document.getElementById("batch").value;

    document.getElementById("name1").innerHTML= name;
    document.getElementById("lname1").innerHTML= lname;
    document.getElementById("iname1").innerHTML= iname;
    document.getElementById("batch1").innerHTML= batch;
    

    tcs = Number(document.getElementById("tcs").value);
    wdl = Number(document.getElementById("wdl").value);
    dloc = Number(document.getElementById("dloc").value);
    bce = Number(document.getElementById("bce").value);
    dbms = Number(document.getElementById("dbms").value);
    cn = Number(document.getElementById("cn").value);

    total = tcs + wdl + dloc + bce + dbms + cn;

    percent = (total/600)*100;

    document.getElementById("total").innerHTML = total;
    document.getElementById("percent").innerHTML = percent.toFixed(2)+"%";

    document.getElementById("tcs1").innerHTML= tcs;
    document.getElementById("cn1").innerHTML= cn;
    document.getElementById("wdl1").innerHTML= wdl;
    document.getElementById("bce1").innerHTML= bce;
    document.getElementById("dbms1").innerHTML= dbms;
    document.getElementById("dloc1").innerHTML= dloc;

    switch(true)
    {
        case(percent>=80):
        document.getElementById("grade").innerHTML="A+";
        break;
        case(percent>=70):
        document.getElementById("grade").innerHTML="A";
        break;
        case(percent>=60):
        document.getElementById("grade").innerHTML="B";
        break;
        case(percent>=50):
        document.getElementById("grade").innerHTML="C";
        break;
        case(percent>=40):
        document.getElementById("grade").innerHTML="D";
        break;
        case(percent<40):
        document.getElementById("grade").innerHTML="Fail";
        break;
    }
}