function add(){
    var a,b,c;
    a = Number(document.getElementById("num1").value);
    b = Number(document.getElementById("num2").value);
    c = a + b;
    document.getElementById("ans").value = c;
}

function swap(){
    var a,b;
    a = Number(document.getElementById("num3").value);
    b = Number(document.getElementById("num4").value);
    c = a;
    a = b;
    b = c;
    document.getElementById("ans1").value = a;
    document.getElementById("ans2").value = b;
}

function fun(){
    var a;
    a=Number(document.getElementById("num5").value);
    if(a%2==0){
        alert("No is Even");
    }
    else{
        alert("No is Odd");
    }

}

function fact(){
    var i,no,fact=1;
    no=Number(document.getElementById("num6").value);
    for (i=1; i<=no; i++)
    {
        fact=fact*i;
    }
    document.getElementById("ans9").value = fact;
}
