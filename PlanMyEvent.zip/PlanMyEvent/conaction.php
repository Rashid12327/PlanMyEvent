<?php
include("checkdb.php");
session_start();
if(isset($_SESSION['user']))
  echo '<h3 align="center"><a href="contactus.php"></a></h3>';
else
  echo '<h3 align="center"><a href="register.php">Please register/login before booking</a></h3>';
  $con=mysqli_connect("localhost","project","project","dbms1");
$email=$_SESSION['user'];
//echo $email;
$sql2="select Uid from users where email='$email'";
$id=mysqli_query($con,$sql2);
$row=mysqli_fetch_assoc($id);
$u_id=$row['Uid'];

    if($_POST['submit'])
            {   
                $name1=$_POST['sname'];
                
                $subject=$_POST['subject'];
                $meassage=$_POST['message'];

                $sql="INSERT INTO user (id,sname,subject,message) values ('$u_id','$name1','$subject','$meassage')";


                if($conn->query($sql)===TRUE)
                {
                    echo"<h4> Your Data is inserted successfully</h2>";
                    header("Refresh:2,url=home.php");
                }
                else
                {
                    echo $conn->error;
                }
            }
        ?>