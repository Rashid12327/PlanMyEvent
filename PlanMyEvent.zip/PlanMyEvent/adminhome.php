<!DOCTYPE HTML>
<html>
    <head>
            <title>PlanMyEvent</title>
            <meta charset="UTF-8">
            <link rel="stylesheet" type="text/css" href="css/admin.css"/>
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <script src="js/main.js"></script>
            
    </head>
    <body>
        <center>
    
        <h1>PlanMyEvent</h1>
        
        </center>
        <header>
        <div class="nav">
        <nav>
        <ul>
                
                <?php session_start();
                if (isset($_SESSION['username'])) {
                ?>
                
				<li><a class="active" href="adminbooking.php">Events</a></li>
                <li><a class="active" href="totalusers.php">Users</a></li>
                
        
        <li><a class="active" href="show_contacts.php">User Contacts</a></li>
                <li style="padding-left:60%"><a class="active" href="adminlogout.php"><i class="fa fa-fw fa-user"></i>Logout</a></li>
				
                <?php

                } else {
                ?>
               <li style="float:right"><a class="active" href="adminlogin.php"><i class="fa fa-fw fa-user"></i>Login</a></li>
                <?php
                } ?>
                
        </ul> 
        </nav>
        </div>
            </Header>
            <p>_____________________________________________________________________________________________________________________________________________________________________________</p>

            <h3>Welcome Admin</h3>
            <footer>
      &copy; 2019  PlanMyEvent ,All Right Reserved .
</footer>
    </body>
</html>

